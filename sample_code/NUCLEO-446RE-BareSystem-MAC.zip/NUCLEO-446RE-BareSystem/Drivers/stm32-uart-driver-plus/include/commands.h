#ifndef COMMANDS_H
#define COMMANDS_H
/**
 * @file commands.h
 * @brief CLI command handlers for demo application.
 */

#include "command_module.h"

#if USE_CMD_INTERPRETER
#include "command_module.h"

/** Print list of supported commands. */
void cmd_help(Args *args);
/** Echo back arguments to the console. */
void cmd_echo(Args *args);
/** Add two integers and output result. */
void cmd_add(Args *args);
/** List active faults. */
void cmd_faults(Args *args);
/** Clear specific or all faults. */
void cmd_fault_clear(Args *args);
/** Set minimum logging level. */
void cmd_log_level(Args *args);

/** Table of available commands. */
extern const Command cmd_list[];
/** Number of commands in ::cmd_list. */
extern const size_t  cmd_count;
#endif

#endif // COMMANDS_H
